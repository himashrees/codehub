package com.example.codehub.repository;



import com.example.codehub.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
    User findByPassword(String password);
    User findByEmailAndPassword(String email, String password); // Modified method
}
