package com.example.codehub.repository;


import com.example.codehub.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository extends JpaRepository<Job, Long> {
}

