package com.example.codehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodehubApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodehubApplication.class, args);
	}

}
